const Footer = () => (
  <footer className="epizon-footer">
    <span className="text-muted">Epizon {new Date().getFullYear()}©</span>
  </footer>
)

export default Footer
